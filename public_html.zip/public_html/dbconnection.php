<?php 
//connect to daatabase
$con= mysqli_connect("localhost","root","","u776060984_donor");
if(mysqli_connect_errno()){
	die ("Sorry!!There is an ERROR Connecting to server!!!");
}
?>
