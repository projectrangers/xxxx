<?php include "dbconnection.php"  ?>
<?php
$login=$_POST['login'];
$password=$_POST['password'];


$query="SELECT* FROM donors WHERE (mobile='$login' OR email='$login') AND password='$password' ";
$total_recs=mysqli_num_rows(mysqli_query($con,$query));
if($total_recs==0){
mysqli_close($con);
	header("location:index.php?message=!!Invalid Username or password!! ");
	exit;	
}
else
{
if(!empty($_POST["remember"])) {
				setcookie ("member_login",$login,time()+ (10 * 365 * 24 * 60 * 60));
				setcookie ("member_password",$password,time()+ (10 * 365 * 24 * 60 * 60));
}


$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);
		session_start();
		$_SESSION["username"]=$login;
		$_SESSION["user_id"]=$row['user_id'];
		if($login=='admin'){
		$_SESSION["user"]='admin';
		}else
		$_SESSION["user"]='normal';
		mysqli_close($con);
		header("location:profile.php");	
}
?>