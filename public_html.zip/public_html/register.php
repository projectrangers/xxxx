<?php include "dbconnection.php"  ?>
<?php 
if(isset($_POST['first_name']) && $_POST['last_name']){
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$email=($_POST['email']);
$mobile=$_POST['mobile'];
$blood_group=$_POST['blood_group'];
$country=$_POST['country'];
$state=$_POST['state'];
$location=$_POST['location'];
$password=$_POST['password'];

 $query="SELECT * from donors WHERE email='$email' OR mobile='$mobile'";
	$res_check=mysqli_query($con,$query);
	$result=mysqli_num_rows($res_check);
	if($result>0){	
   //die("Ooops!!!<br><br>You have Already Registered!!!!");
  $mes= "!!!!You have Already Registered!!!!";

  header("location:index.php?message=$mes#reg");
	}
else{
$query="INSERT INTO 
donors(first_name,last_name,email,mobile,blood_group,country,state,location,password) VALUES
      ('$first_name','$last_name','$email','$mobile','$blood_group','$country','$state','$location','$password')";
if(!mysqli_query($con,$query)){

				header("location:index.php?message=mysqli_error($con)"); 
		//die(mysqli_error($con));
	}
	else{
   $mes="Dear,".$_POST['first_name'] ."!!!!<br><br>"."You have successfully Registered";
   header("location:index.php?message=$mes");

}
}
}	
?>