<?php session_start(); ?>
<?PHP $id=$_SESSION['user_id']; 
?>


<?PHP if(!isset($_SESSION['user']))
header("location:forbidden.php");
?>
<html>

<head>
      <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
</head>

 <?php include("includes/common-header.php")?>
<body id="page-top" style="margin-top:59px">


<?php include "dbconnection.php"?>
<?php 
$query="select *from donors where user_id=$id";
$result = mysqli_query($con, $query);
mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
?>
	<div class="container well">
	 <u><h2>Profile</h2></u>
	 <?php if(isset($_GET['message']) && $_GET['message']!='')
{    echo " <div class='well well-sm'> <center>	<h4><span style='color:red'>";
	$msg=$_GET['message'];
	echo $msg;
	echo "</h4></center> </div>	";
}
?>
	 <h4 style="color:red">Note:Please Complete the incomplete information to Enable Verification.Incomplete profile Cannot verified.</h4>
	 <h4 style="color:red">you will not shown to Accepted unless your profile is not verified.</h4>
	<div class="row">
	<div class="col-sm-3">
   <img width="250px" height="250px" src="img/donors/<?php echo $row['profile_pic']?>">
   <form action="upload.php" method="post" enctype="multipart/form-data">
    upload profile picture:
    <input type="file" name="fileToUpload" id="fileToUpload">
	 <input type="hidden" name="user_id" value="<?php echo $row['user_id']?>">
    <input type="submit" value="Upload Image" name="submit">
   </form>
   <div class="well">
   <ul class="list-group">
  <li class="list-group-item"><strong>Registered On:</strong><?php echo $row['registered_on'];?></li>
  <li class="list-group-item"><strong>Verification Status:</strong><?php if($row['verified']==1) echo "verified";else echo "Not Verified" ?></li>
  <li class="list-group-item"><strong>Visibility:</strong><?php if($row['visible']==1) echo "visible";else echo "Not visible" ?></li>
  </ul>
   </div>
   
   
    </div>
<div class="col-sm-8 well">
 <div class="well">
  <div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Password:</div>
                    <div class="col-sm-6">
					<form action="change_password.php" method="POST">
			        Enter New Password:<input name="password" type="password" class="form-control"/><br>
					   <input type="hidden" name="id" value="<?php echo $row['user_id']?>">
					 <input type="submit" class="btn btn-info btn-sm" value="change">
				   </form>
				   </div>
           </div>
		</div> 
		</div>
  <form role="form" action="update_profile.php" method="POST">
 
  <input type="hidden" name="user_id" value="<?php echo $row['user_id']?>">
        <div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">First Name:</div>
                    <div class="col-sm-6">
			            <input readOnly name="first_name" type="text" class="form-control" value="<?php echo $row['first_name']?>" >
				   </div>
           </div>
		</div> 
		
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Last Name:</div>
                    <div class="col-sm-6">
			            <input readOnly name="last_name" type="text" class="form-control" value="<?php echo $row['last_name']?>" >
				   </div>
           </div>
		</div> 
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">DOB(dd/mm/yyyy):</div>
                    <div class="col-sm-6">
			            <input name="dob" type="text" class="form-control" value="<?php echo $row['dob']?>">
				   </div>
           </div>
</div> 
	

<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Occupation:</div>
                    <div class="col-sm-6">
			            <input name="job" type="text" class="form-control" value="<?php echo $row['job']?>" >
				   </div>
           </div>
</div> 


<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Relationship:</div>
                    <div class="col-sm-6">
			            <input name="relationship" type="text" class="form-control" value="<?php echo $row['relationship']?>" >
				   </div>
           </div>
</div> 	
		
		
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Email:</div>
                    <div class="col-sm-6">
			            <input readOnly name="email" type="email" class="form-control" value="<?php echo $row['email']?>" >
				   </div>
           </div>
		</div>
		
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Mobile:</div>
                    <div class="col-sm-6">
			            <input readOnly name="mobile" type="tel" maxlength="10" class="form-control" value="<?php echo $row['mobile']?>" >
				   </div>
           </div>
</div> 

<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Blood Group:</div>
                    <div class="col-sm-6">
			         <input readOnly name="blood_group" type="text" class="form-control" value="<?php echo $row['blood_group']?>" >    
				   </div>
           </div>
</div> 
<div class="well">
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Address:</div>
                    <div class="col-sm-6">
			         Address line 1:   <input name="address1" type="text" class="form-control" value="<?php echo $row['address1']?>" >
					  Address line 2:   <input name="address2" type="text" class="form-control" value="<?php echo $row['address2']?>" >
					   City/Location:   <input readOnly name="location" type="text" class="form-control" value="<?php echo $row['location']?>">
					    State:          <input readOnly name="state" type="text" class="form-control"value="<?php echo $row['state']?>" >
						 Country:       <input readOnly name="country" type="text" class="form-control" value="<?php echo $row['country']?>" >
				          PIN:       <input name="pin" type="text" class="form-control" value="<?php echo $row['pin']?>" >
				   </div>
           </div>
</div>	
</div>	

 
<div class="well">
<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Government Issued ID:</div>
                    <div class="col-sm-6">
					 Type :
					 <select class="form-control" name="gov_id_type" id="gov_id_type">
					  <option>--Select--</option>
					  <option>Aadhar</option>
					   <option>Voter Id</option>
					    <option>Election Id</option>
						 <option>Driving License</option>
						<option>Other</option>
					</select>
			     <div id="mainId">ID.<input name="gov_id" type="text" class="form-control" value="<?php echo $row['gov_id']?>" ></div>
				<div id="other" style="display:none">Other ID.<input name="other_id" type="text" class="form-control" value="<?php echo $row['other_id']?>" ></div>
									   </div>
           </div>
</div>
</div>


<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">Physically Challenged:</div>
                    <div class="col-sm-6">
					<input readOnly name="other_gov_id" type="text" class="form-control" value="<?php echo $row['physically_challenged'];?>" >
			            <select name="physically_challenged" class="form-control" >
						<option value="no">NO</option>
						<option value="yes">YES</option>
					   
						</select>
				   </div>
           </div>
</div> 

<div class="form-group">
            <div class="row">
		        <div class="col-sm-3 lbl">comment</div>
                    <div class="col-sm-6">
					<textArea name="comment" class="form-control"><?php echo $row['comment'];?></textArea>
				   </div>
           </div>
</div> 
<div class="row">
<div class="col-sm-6"><button id="back" class="btn btn-danger">Back</button></div>
<div class="col-sm-6"><input type="submit"class="btn btn-large btn-info"></div>
</div>		
  </form> 
</div>
</div>	
</div>
	
	
	
	
	
<?php mysqli_close($con); ?>
	<script>
	document.getElementById("back").onclick=function(){
	history.go(-1);
	};
	</script>
     <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#gov_id_type").change(function () {
            if ($(this).val() == "Other") {
                $("#other").show();
				 $("#mainId").hide();
            } else {
                $("#other").hide();
				 $("#mainId").hide();
            }
        });
    });
</script>
</body>
<?php include("includes/footer.html");?>
</html>