

   <nav id="mainNav" class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid" style="position:relative">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
			           <a class="navbar-brand page-scroll" href="index.php"><span id="logo1">The Blood<span id="logo2">Bank</span></span></a>
                <button type="button" style="color:red;font-weight:bold" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>

            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
					
                        <a class="page-scroll " style="color:red;font-weight:bold" href="#page-top"><span class="glyphicon glyphicon-search fa-lg" aria-hidden="true"> Search</span></a>
                    </li>                   
				   <li>
                        <a class="page-scroll " style="color:red;font-weight:bold" href="#aboutus"><span class="glyphicon glyphicon-eye-open fa-lg" aria-hidden="true"> Learn</span></a>
                    </li>
                    <li>
                        <a class="page-scroll " style="color:red;font-weight:bold" href="#donors"><span class="glyphicon glyphicon-king fa-lg" aria-hidden="true"> OurTopDonors</span></a>
                    </li>
					 <li>
                        <a class="page-scroll " style="color:red;font-weight:bold" href="#contact"><span class="glyphicon glyphicon-envelope fa-lg" aria-hidden="true"> contact</span></a>
                    </li>
					<?php if(!isset($_SESSION['username'])){?>
					<li>
                        <a class="page-scroll " style="color:red;font-weight:bold" href="#reg"><span class="glyphicon glyphicon-globe fa-lg" aria-hidden="true"> RegisterAsDonor</span></a>
                    </li>
					 <li>
                        <a href="#" style="color:red;font-weight:bold" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-log-in fa-lg" aria-hidden="true"> Login</span></a>
                     </li>
					 
					
					<?php } else{?>
					
					 <li>
                        <a href="profile.php" ><span class="glyphicon glyphicon-user fa-lg" aria-hidden="true"> <?php echo "welcome:".$_SESSION['username']; ?></span></a>
                     </li>
					 
					 
					 
					 
					  <?php if($_SESSION['user']=='admin'){ ?>
					  <li>
					 <a href="newRegistration.php"><span class="glyphicon glyphicon-bullhorn fa-lg" aria-hidden="true"> NewRegistrations</span></a>
					 </li>
					 <li>
					 <a href="admin.php"><span class="glyphicon glyphicon-alert fa-lg" aria-hidden="true"> SeeBloodRequest</span></a>
					 </li>
					
					 <li>
					 <a href="donors.php"><span class="glyphicon glyphicon-list-alt fa-lg" aria-hidden="true"> SeeDonors</span></a>
					 </li>
					 <?php } ?>
					 
					  <li>
					 <a href="logout.php"><span class="glyphicon glyphicon-log-out fa-lg" aria-hidden="true"> Logout</span></a>
					 </li> 
					<?php }?>
					
					
					
                    
					
					
                    
					 
				       
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<br>