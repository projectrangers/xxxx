<?php include "dbconnection.php"  ?>
<?php 
if(isset($_POST['name']) && $_POST['mobile']){
$name=$_POST['name'];
$address=$_POST['address'];
$mobile=$_POST['mobile'];
$hospital_name=$_POST['hospital_name'];
$hospital_address=$_POST['hospital_address'];
$reason=$_POST['reason'];
$donor_id=$_POST['donor_id'];

$query="INSERT INTO request(request_id,name,address,mobile,hospital_name,hospital_address,reason,request_to_donor_id)
VALUES('','$name','$address','$mobile','$hospital_name','$hospital_address','$reason',$donor_id)";
if(!mysqli_query($con,$query)){
         mysqli_close($con);
		die("Error!!!".mysqli_error($con));
	}
	else{
mysqli_close($con);
   header("location:success.php?message=Thank you.<br>We will get back to you soon!!");
}}	
?>