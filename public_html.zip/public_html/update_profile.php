<?php include "dbconnection.php"?>
<?php
$user_id=$_POST['user_id'];
$dob=$_POST['dob'];
$job=$_POST['job'];
$relationship=$_POST['relationship'];
$address1=$_POST['address1'];
$address2=$_POST['address2'];
$pin=$_POST['pin'];
$gov_id_type=$_POST['gov_id_type'];
$gov_id=$_POST['gov_id'];
$comment=$_POST['comment'];
$physically_challenged=$_POST['physically_challenged'];
$other_id=$_POST['other_id'];
$query="UPDATE donors
SET dob='$dob',
job='$job',
relationship='$relationship',
address1='$address1',
address2='$address2',
pin='$pin',
gov_id_type='$gov_id_type',
gov_id='$gov_id',
physically_challenged='$physically_challenged',
comment='$comment',
other_id='$other_id'
WHERE user_id='$user_id'";
if (mysqli_query($con, $query)) {
   header("location:profile.php?message=Profile Updated Successfully&id=$user_id");
} else {
header("location:profile.php?message=$con->error&id=$user_id");
    //echo "Error updating record: " . mysqli_error($con);
}

mysqli_close($con);
?>

