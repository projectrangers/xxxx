<?php session_start(); ?>
<html>

<head>

      <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Success</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
   
<style>
.redicn{
color:red;
}
</style>

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" style="color:red;font-weight:bold" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="index.php"><span class="glyphicon glyphicon-home fa-lg" aria-hidden="true"> TheBloodBank</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                  
					<?php if(!isset($_SESSION['username'])){
					?>
					<li>
                        <a class="page-scroll" style="color:red;font-weight:bold" href="index.php"><span class="glyphicon glyphicon-globe fa-lg" aria-hidden="true"> RegisterAsDonor</span></a>
                    </li>
					 <li>
                        <a href="index.php" style="color:red;font-weight:bold"><span class="glyphicon glyphicon-log-in fa-lg" aria-hidden="true"> Login</span></a>
                     </li>
					<?php } else{?>
					
					 <li>
                        <a href="profile.php" ><span class="glyphicon glyphicon-user fa-lg" aria-hidden="true"><?php echo "welcome:".$_SESSION['username']; ?></span></a>
                     </li>
                     
					  <?php if($_SESSION['user']=='admin'){ ?>
					 <li>
					 <a href="admin.php"><span class="glyphicon glyphicon-alert fa-lg" aria-hidden="true"> SeeBloodRequest</span></a>
					 </li>
					 <li>
					 <a href="newRegistration.php"><span class="glyphicon glyphicon-bullhorn fa-lg" aria-hidden="true"> NewRegistrations</span></a>
					 </li>
					 <li>
					 <a href="donors.php"><span class="glyphicon glyphicon-list-alt fa-lg" aria-hidden="true"> SeeDonors</span></a>
					 </li>
					 <?php } ?>
					 <li>
					 <a href="logout.php"><span class="glyphicon glyphicon-log-out fa-lg" aria-hidden="true">Logout</span></a>
					 </li>
					<?php } ?>
				                
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<br><br><br><br>








<center><img src="img/drop.png" width="200px" height="200px"></center>
	 <?php if(isset($_GET['message']) && $_GET['message']!='')
{  echo " <div class='well well-sm'> <center>	<h2><span style='color:red'>";
	$msg=$_GET['message'];
	echo $msg;
	echo "</h2></center> </div>	";
}
?>
	
	<script>
	document.getElementById("back").onclick=function(){
	history.go(-1);
	};
	</script>
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>


    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
</body>

</html>