﻿<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en">

<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>New Registrations</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
   
<style>
.redicn{
color:red;
}
</style>

</head>
<?php include("includes/common-header.php") ?>
<body id="page-top" style="margin-top:59px">

  
<?php include "dbconnection.php"?>
<?php 
$query="SELECT * FROM donors where verified=0";
$result = mysqli_query($con, $query);


?>
	
	
	
	
	
	
	
<div class="container"> 
<h2>New Registrations</h2>
<ul class="list-group">
<?php 
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
?>

<li class="list-group-item">            
<div class="row">

<div class="col-sm-2" >
<?php echo $row['first_name']; ?>&nbsp<?php echo $row['last_name']; ?>
</div> 
<div class="col-sm-2">
<a href="showprofile.php?id=<?PHP echo $row['user_id']?>"><button class="btn btn-info">SHOW</button></a>
</div>
</div>
</li>
<?php   
    }
	echo "</ul>";
} else {
    echo "<center><img width='200px' height='200px' class='img-responsive' src='img/drop.png'>";
    echo "<h1>SORRY NO NEW REGISTRATIONS</h1></center>";
}


?>
	
	  </div>
</div>	
	<br><br>	<br><br>	<br><br> 	<br><br>
<?php mysqli_close($con); ?>	
	
   <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
	<?php include("includes/footer.html") ?>
</body>

</html>
