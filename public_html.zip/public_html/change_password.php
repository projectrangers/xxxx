<?php include "dbconnection.php";
$password=$_POST['password'];
$id=$_POST['id'];
?>
 

<?php
if($_POST['password']!=''){
$query="UPDATE donors
SET password='$password'
WHERE user_id='$id'";
if (mysqli_query($con, $query)) {
 header("location:profile.php?message=Password updated Successfully!!&id=$id");
} else{
    echo "Error updating record: " . mysqli_error($con);
}
mysqli_close($con);
}else
header("location:profile.php?message=Password can't be blank!!&id=$id");
?>