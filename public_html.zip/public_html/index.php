<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home|TheBlood Bank</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
   
<style>
.redicn{
color:red;
}


</style>

</head>
  <?php if(isset($_SESSION['user']) && $_SESSION['user']=='admin'){ ?>
<body id="page-top" style="position:relative;top:59px" >
  <?php } ?>
<body id="page-top" style="position:relative;top:30px" >
 <?php include("includes/index-header.php")?>
		
		 
		 <!--donate button -->
    <header style="top:80">
       <div class="header-content">
			 
	  
	<?php if(isset($_GET['message']) && $_GET['message']!='')
{    echo " <div class='well well-sm'> <center>	<h2><span style='color:red'>";
	$msg=$_GET['message'];
	echo $msg;
	echo "</span> <button type='button' class='btn btn-warning btn-sm' data-toggle='modal' data-target='#myModal'>Login Here</button></h2></center> </div>	";
}
?>

		
		


            <div class="header-content-inner" id="search" >
           <h1 style="color:red;font-weight:bold">Find Out Thousands of Blood Donors From Our Database!!</h1>
		   <h2>Search Here!!!</h2><br>
		   
		   
<form class="form-inline" role="form" action="searchResult.php">
  <div class="form-group">
    <input type="text" class="form-control m" name="blood_group" placeholder="Blood Group">
  </div>
  <div class="form-group">
    <input type="text" class="form-control m" name="location" placeholder="Location">
  </div>
  <br>  <br>
  <button type="submit" class="btn btn-default"> <i class="glyphicon glyphicon-search fa-2x">Search</i></button>
</form>
<br>
OR
<br><br>
<a href="#reg" class="page-scroll"><button class="btn-danger btn-lg ">Register As Donor</button></a>
<br><br>
<a href="https://www.payumoney.com/paybypayumoney/#/F4112566ECFBE983CC16CF5D9EDB35C0">
    <img width="150px" src="img/donate.png" />
</a>
</div>

  
 
</div>
</header>

    <section class="bg-primary" id="aboutus">
     <div class="container">

            <div class="row">
                <div class="col-lg-4">
                    <h2 class="section-heading">Why Donate Blood?</h2>
                    <hr class="light">
                    <p>
				Safe blood saves lives and improves health. Blood transfusion is needed for:
					</p>
					<h4>
					<li>women with complications of pregnancy, such as ectopic pregnancies and haemorrhage before, during or after childbirth;
                    <li>children with severe anaemia often resulting from malaria or malnutrition;
                    <li>people with severe trauma following man-made and natural disasters; and
                    <li>many complex medical and surgical procedures and cancer patients.</p>
					
				Blood is the most precious gift that anyone can give to another
				person — the gift of life. A decision to donate your blood can save a life,
				or even several if your blood is separated into its components — red cells,
				platelets and plasma — which can be used individually 
				for patients with specific conditions
					</h4>
					  </div>
            
			 <div class="col-lg-4">
                    <h2 class="section-heading">How Donate Blood?</h2>
                    <hr class="light">
                    <p>
				If you Think that You can help someone to save their life,
				by donating blood.
					</p>
					<p>
					You can Simply REgister yourself by 
					<center><a href="#reg" class="page-scroll btn btn-default btn-sm sr-button">Clicking Here</a></center>
				   </p>
					<p>
					So,Earn blessings and make Smile to SomeOne.Saving their Life.
					</p>
					<img class="img-responsive" src="img/life.png">
					<br>
                    
                </div>
				<div class="col-lg-4 text-center">
				<h2 class="section-heading">Who can Donate Blood?</h2>
                    <hr class="light">
					<h4>
					<li>Any donor, who is healthy,
					fit and not suffering from any transmittable diseases can
					donate blood
					<li>Donor must be 18 -60 years age and having a minimum weight of
					50Kg can donate blood
					<li>A donor can again donate blood after 3 months of your last donation of blood.
					<li>Pulse rate must be between 50 to 100mm without any irregularities.
					<li>BP Diastolic 50 to 100 mm Hg and Systolic 100 to 180 mm Hg.
					<li>Body temperature should be normal and oral temperature should not exceed 37.5 degree Celsius.
					</h4>
				</div>
            </div>
        </div>
		</div>
    </section>
	
	
	  <section id="donors" class="no-padding">
        <div class="container">
<?php include "dbconnection.php" ?>
<?php 
$query="SELECT * FROM donors AS A where (Select count(*) from donors as B where  B.donation_count > A.donation_count) < 3 AND A.verified=1 AND A.visible=1  AND A.donation_count IS NOT NULL  ORDER BY A.donation_count DESC";
$result = mysqli_query($con, $query);
?>

<div class="container text-center">
  <h1 style="color:white">Our Top Donors</h1>
  <p><em>May God Bless Them!</em></p>
  <br>
  <div class="row">
  <?php 
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
?>
    <div class="col-sm-4">
     
  <a href="requestpage.php?id=<?PHP echo $row['user_id']?>"><img src="img/donors/<?php echo $row['profile_pic']?>" class="img-circle person" alt="Random Name" width="255" height="255"></a>
	   <h3 class="text-center"><strong style="color:white"><?php echo $row['first_name']." ".$row['last_name']; ?></strong></h3>
	  <h5 class="text-center"><strong style="color:white"><?php echo $row['location']; ?>
											 <?php echo ",". $row['state'];?></strong></h5><br>
    </div>
   <?php }} ?> 
</div>
    </section>
 <aside class="" id="reg" >
        <div class="container text-center">
            <div class="call-to-action">
                <h2 style="color:white">Save A Life!! Donate Blood in Emergency When it Needed!</h2>
	
		<i class="fa fa-2x text-primary sr-icons"><strong>Register As Donor</strong></i><br>
		<i class="fa fa-arrow-down fa-4x text-primary sr-icons"></i>
                </div>
            </div>
            </div>
        </div>
    </aside>
    <section class="no-padding"  id="register">
		<br> 
        <div class="container">
            <div class="row">
			<div class="col-sm-7" >

			
		<img src="img/header1.jpg" height="900px;" class="img-responsive"></div>
		
		<div class="col-sm-5  text-center" align="center">
				<!--FORM-->
					<div class="well">
					<span style="color:red;font-weight:bold">Note:-Please Fill Correct Details,So that we might able to contact you in an Emergency.</span>
                  <form action="register.php" method="POST" class="form-">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                             <div class="input-group">
								<span class="input-group-addon"><span class="glyphicon glyphicon-user redicn" ></span></span>
                           <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Enter first name" required="required" />
						   </div>
                        
						</div>

						
						
						<div class="form-group">
                         
								 <div class="input-group">
								<span class="input-group-addon"><span class="glyphicon glyphicon-user redicn"></span>
                                </span>
                            <input type="text" name="last_name" class="form-control" id="last_name" placeholder="Enter last name"  /></div>
                        </div>
						
						
                        <div class="form-group">
                      
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope redicn"></span>
                                </span>
                                <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" /></div>
                        </div>
						
						
						  <div class="form-group">
                           
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-phone redicn"></span>
                                </span>
                                <input type="tel" maxlength="10" name="mobile" class="form-control" id="email" placeholder="Enter Mobile Number" required="required" /></div>
                        </div>
						
						
                        <div class="form-group">
                            

                            <select id="blood_group" name="blood_group" class="form-control" required="required">
                                 <option>---Select Blood Group---</option>
								 <option>A</option>
								 <option>A+</option>
								 <option>A-</option>
								 <option>B</option>
								 <option>B+</option>
								 <option>AB+</option>
								 <option>AB-</option>
								 <option>O</option>
								 <option>O+</option>
								 <option>O-</option>
								
                              
                            </select>
							<br>
				
							<div class="form-group">
                           
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope redicn"></span>
                                </span>
                                <input type="text" name="country" class="form-control" id="country" value="INDIA" required="required" readOnly="readOnly" /></div>
                             </div>
							 
							 
							  <select id="state" name="state" class="form-control" required="required">
                                 <option>---Select State---</option>
								 <option>Andhra Pradesh</option>
								 <option>Arunachal Pradesh</option>
								 <option>Assam</option>
								 <option>Bihar</option>
								 <option>Chattisgarh</option>
								 <option>Goa</option>
								 <option>Gujrat</option>
								 <option>Hariyana</option>
								 <option>Himachal Pradesh</option>
								 <option>Jammu and Kashmir</option>
								 <option>Jharkhand</option>
								 <option>Karnataka</option>
								 <option>Kerala</option>
								 <option>Madhya pradesh</option>
								 <option>Maharashtra</option>
								 <option>Manipur</option>
								 <option>Meghalaya</option>
								 <option>Mizoram</option>
								 <option>Nagaland </option>
								 <option>Oddisa</option>
								 <option>Punjab</option>
								 <option>Rajasthan</option>
								 <option>Sikkim</option>
								 <option>Tamil Nadu</option>
								 <option>Telangana</option>
								 <option>Tripura</option>
								 <option>uttarakhand</option>
								 <option>Uttar Pradesh</option>
								 <option>West Bengal</option>
								
								
                              
                            </select>
							<br>
							 <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-home redicn"></span>
                                </span>
                                <input type="text" name="location" class="form-control" id="location" placeholder="city/place/Locality" required="required" /></div>
                             </div>
							 
							 
							 <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock redicn"></span>
                                </span>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Create Password" required="required" /></div>
                             </div>
							 <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock redicn"></span>
                                </span>
                                <input type="password" class="form-control" id="retype_password" placeholder="Retype password" required="required" /></div>
                             </div>
                        </div>
						<button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                            Register</button>
                    </div>
                </div>
                </form>
</div>	
</div>			
                </div>
				
				
            </div>
        </div>
		<br>
    </section>



 
<?php include("includes/footer.html") ?>


<?php mysqli_close($con); ?>
	
  <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
</body>

</html>
