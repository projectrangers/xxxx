<!DOCTYPE html>
<?php session_start(); ?>
<?PHP 
if($_SESSION['user']!='admin')
header("location:forbidden.php");
 ?>
<html lang="en">

<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home|Admin</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
</head>

<body id="page-top" style="margin-top:59px">

    <?php include("includes/common-header.php"); ?>

<?php include "dbconnection.php"?>
<H1>REQUESTS</H1>
<div class="table-responsive">
<table class="table" style="border:solid;width:100%;text-align:center" align="center" border="1">
<tr>
<th>Request_Id
<th>Name
<th>Address
<th>Mobile
<th>Hospital Name
<th>Hospital Address
<th>Reason
<th>time
<th>Request to donor_id
</tr>
<?php

$query="SELECT * FROM request";
$result = mysqli_query($con, $query);
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
?>
<tr>
<td><?php echo $row['request_id']?>
<td><?php echo $row['name']?>
<td><?php echo $row['address']?>
<td><?php echo $row['mobile']?>
<td><?php echo $row['hospital_name']?>
<td><?php echo $row['hospital_address']?>
<td><?php echo $row['reason']?>
<td><?php echo $row['time']?>
<td><?php echo $row['request_to_donor_id']." "?><a href="showprofile.php?id=<?php echo $row['request_to_donor_id']?>">Show Profile</a>

</tr>




<?php }} mysqli_close($con); ?>
</table>
</div>
</div>
<h1 align="center">
<a href="index.php">Home</a>
<a href="profile.php">profile</a>
</h1>


<?php include("includes/footer.html")?>
</body>
</html>