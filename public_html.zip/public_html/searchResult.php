<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en">

<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Search</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
<style>
.redicn{
color:red;
}
</style>

</head>

<body id="page-top">

   <?php include("includes/common-header.php")?>
<?php include "dbconnection.php"?>
<?php 
$blood_group=$_GET['blood_group'];
$location=$_GET['location'];

if(($blood_group=="" )&&($location=="")){
	$query="SELECT * FROM donors where verified=1 AND visible=1
			order by blood_group ASC";
}
if($blood_group==""){
	$query="SELECT * FROM donors where(
            location like    '%$location%'
            OR state like    '%$location%' 
            OR country like  '%$location%' 
            OR address1 like '%$location%'
            OR address2 like '%$location%')
			AND verified=1 AND visible=1
			order by blood_group ASC";
	
	
}else


$query="SELECT * FROM donors where(
            location like    '%$location%'
            OR state like    '%$location%' 
            OR country like  '%$location%' 
            OR address1 like '%$location%'
            OR address2 like '%$location%')
			AND blood_group like '$blood_group' 
			AND verified=1 AND visible=1
			order by blood_group ASC";
			

$result = mysqli_query($con, $query);


?>
	
	
	
	
	
	
	<div class="jumbotron well">
	      <div class="container well">
	         <div class="row">
			    <div class="col-sm-6">
	              <h1>Search Result</h1>
		           
				        <div class="col-sm-offset-1 well">
					        <p><?php echo mysqli_num_rows($result); ?> Results Found for Location <span style="color:red"><?php if($_GET['location']=='') echo "everywhere"; else echo $_GET['location'] ?></span> and Blood Group <span style="color:red"><?php if($_GET['blood_group']=='') echo "All"; else echo $_GET['blood_group']; ?></span></p>
					    </div>
				  
				</div>
				<br><br><br>
				  <div class="col-sm-6">
				      <form class="form-inline" role="form" action="searchResult.php">
                          <div class="form-group">
                                <input type="text" class="form-control m" name="blood_group" placeholder="Blood Group">
                            </div>
                           <div class="form-group">
                                 <input type="text" class="form-control m" name="location" placeholder="Location">
                           </div>
                             <br>  <br>
                              <button type="submit" class="btn btn-default"> <i class="fa fa-2x fa-search text-primary sr-icons">Search</i></button>
                       </form>
				  </div>
			 </div>
	      </div>
	</div>
	
	<div class="container well">
      <div class="row">
	 
<?php 
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
?>

             <div class="col-sm-4"> 
           <center>  <a href="requestpage.php?id=<?PHP echo $row['user_id']?>"> <img width="200px" height="200px" src="img/donors/<?php echo $row['profile_pic'] ?>" class="img-circle" alt="<?php echo "profile".$row['profile_pic'] ?>"></a></center>
	                 <div class="alert alert-success">
                             <p class="text-center" >
							 <span style="color:red"><?php if($row['verified']==1){echo "<img src='img/verified.png' width='20px'>";}else echo "<img src='img/not-verified.png' width='20px'>" ?></span>
							       <strong > <?php echo $row['first_name']." ".$row['last_name']; ?></strong>
                                         <p class="text-center">
										     <strong>Location:</strong>
											 <?php echo $row['location']; ?>
											 <?php echo ",". $row['state'];?>
				
										 </p>
										  <p class="text-center" style="color:red">
										     <strong>Blood Group:</strong>
											<?php echo $row['blood_group'];?>
				
										 </p>
									
                             </p>
                      </div>
             </div>
  

<?php   
    }
} else {
    echo "<center><img width='200px' height='200px' class='img-responsive' src='img/drop.png'>";
    echo "<h1>SORRY NO DONORS FOUND</h1></center>";
}


?>
	
	  </div>
</div>	
	
<?php mysqli_close($con); ?>	
	
   <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
	<?php include("includes/footer.html") ?>
</body>

</html>
