
<?PHP 
session_start();
if($_SESSION['user']!='admin')
header("location:forbidden.php");
 ?>
 
<?PHP $id=$_GET['id']; 
if($id==''){
header("location:forbidden.php");
}
?>
<?php
include "dbconnection.php";
$query="UPDATE donors
SET visible=1
WHERE user_id='$id'";
if (mysqli_query($con, $query)) {
 header("location:showprofile.php?message=Account UnBlock Success&id=$id");
} else{
    echo "Error updating record: " . mysqli_error($con);
}
mysqli_close($con);
?>