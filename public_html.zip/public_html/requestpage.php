<?PHP $id=$_GET['id']; ?>
<?php session_start(); ?>
<html>

<head>

      <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>RequestPage</title>

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/creative.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">

   
<style>
.redicn{
color:red;
}
</style>

</head>
<?php include("includes/common-header.php")?>
<body id="page-top" style="margin-top:59px;">

<div class="well">
<center><h4 style="color:red">Enter your Detail here and reason for which blood is required.We will send the required donor as soon as possible to the given hospital.</h4></center>
</div>

<?php include "dbconnection.php"?>
<?php 
$query="select *from donors where user_id=$id";
$result = mysqli_query($con, $query);
mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
?>

<div class="container well">
<div class="row">
<div class="col-sm-3 well">
<img width="250px" height="250px" src="img/donors/<?php echo $row['profile_pic']?>">

<center>
<h2>Blood Group:<?php echo $row['blood_group']?></h2>
<h3><?php echo $row['first_name']." ".$row['last_name']?></h3>
<h4><?php echo $row['location']?></h4>
<h4><?php echo $row['state']?></h4>
</center>
</div>
<div class="col-sm-9">
<h2>Enter Your Detail</h2>
  <form role="form" action="request_process.php" method="POST">
  <input name="donor_id" type="hidden" value="<?PHP echo $id ?>" >
    <div class="form-group">
      <label>*Full Name:</label>
      <input required name="name" type="text" class="form-control" placeholder="Enter Full Name">
    </div>
    <div class="form-group">
      <label>Address:</label>
      <textarea name="address" class="form-control" placeholder="Enter Complete Address"></textarea>
    </div>
	<div class="form-group">
      <label>*Mobile Number:</label>
      <input required name="mobile" type="text" maxlength="10" class="form-control" placeholder="Enter Your Mobile Number">
    </div>
	<div class="form-group">
      <label> *Hospital Name:</label>
      <input required name="hospital_name" type="text"  class="form-control" placeholder="Enter Hospital name">
    </div>
	<div class="form-group">
      <label> *Hospital Address:</label>
      <input required name="hospital_address" type="text"  class="form-control" placeholder="Enter Hospital address">
    </div>
	<div class="form-group">
      <label> *Describe Reason:</label>
     <textarea required name="reason" class="form-control" placeholder="Enter Reason for which blood is required"></textarea>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>
<div>
</div>

</div>
</div>








<?php mysqli_close($con); ?>
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>


    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
    <?php include("includes/footer.html")?>
</body>
</html>